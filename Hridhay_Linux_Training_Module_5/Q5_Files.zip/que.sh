#!/bin/bash

search(){
 local dir=$1
 local key=$2
 for file in $dir/*;
 do
   if [[ -d "$file" ]]; then
      search "$file" "$key"
   elif [[ -f "$file" ]]; then
      if  grep -q "$key" "$file" ; then
         echo "$file"
      fi
   else 
      echo "Directory doesn't exists" | tee -a errors.log
   fi
 done
}

search_f(){
 local fil=$1
 local key=$2
 if [[ -e "$fil" ]]; then
    if  grep -q "$key" "$fil" ; then
         echo "Key is present in file"
      fi
 else 
 echo "Error: File doesn't exist" | tee -a errors.log
 fi
}

show_help(){
 cat << eof
Usage $0 [options]
Options:
 -d <directory> : Search for files in directory recursively
 -f <file> : Search for keyword in file
 -k <keyword> : Search for keyword in a specific file
 --help : Display the help menu
eof
}

while getopts "d:f:k:-:" opt ; do
case "$opt" in 
d) dir="$OPTARG";;
f) fil="$OPTARG";;
k) key="$OPTARG";;
-) case "$OPTARG" in
   help) show_help;exit 0;;
   *) echo "Inavlid option $OPTARG" | tee -a errors.log; exit 1;;
   esac
   ;;
\?) echo "Inavlid option $OPTARG" | tee -a errors.log; exit 1;;
esac
done

if [[ -z "$key" ]]; then
echo "Key is not given" | tee -a errors.log
exit 1
fi

if [[ -n "$dir" ]]; then
search "$dir" "$key"
fi

if [[ -n "$fil" ]]; then
search_f "$fil" "$key"
fi

