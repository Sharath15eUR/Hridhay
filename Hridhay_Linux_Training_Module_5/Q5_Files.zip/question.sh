#!/bin/bash
err_log="errors.log"
search_directory() {
    local dir="$1"
    local keyword="$2"
    
    for file in "$dir"/*; do
        if [[ -d "$file" ]]; then
            search_directory "$file" "$keyword"
        elif [[ -f "$file" ]]; then
            if grep -q "$keyword" "$file" 2>> "$err_log"; then
                echo $file
            fi
        fi
    done
}
show_help() {
    cat << EOF
Usage: $0 [options]

Options:
  -d <directory>  Search for files in directory recursively.
  -k <keyword>    Keyword to search for.
  -f <file>       Search for keyword in a specific file.
  --help          Display this help menu.

Example usage:
  $0 -d logs -k error
  $0 -f script.sh -k TODO
  $0 --help
EOF
}
validate_input() {
    local keyword="$1"
    local file="$2"
    local directory="$3"
    
    if [[ -n "$file" && ! -f "$file" ]]; then
        echo "Error: File '$file' does not exist." | tee -a "$err_log"
        exit 1
    fi
    
    if [[ -n "$directory" && ! -d "$directory" ]]; then
        echo "Error: Directory '$directory' does not exist." | tee -a "$err_log"
        exit 1
    fi
    
    if [[ -z "$keyword" || ! "$keyword" =~ ^[a-zA-Z0-9_]+$ ]]; then
        echo "Error: Invalid keyword. Only alphanumeric and underscore allowed." | tee -a "$err_log"
        exit 1
    fi
}
while getopts ":d:k:f:-:" opt; do
    case "$opt" in
        d) directory="$OPTARG" ;;
        k) keyword="$OPTARG" ;;
        f) file="$OPTARG" ;;
        -)
            case "$OPTARG" in
                help) show_help; exit 0 ;;
                *) echo "Invalid option: --$OPTARG" | tee -a "$err_log"; exit 1 ;;
            esac
            ;;
        ?) echo "Invalid option: -$OPTARG" | tee -a "$err_log"; exit 1 ;;
    esac
done
if [[ -z "$keyword" ]]; then
    echo "Error: A keyword must be provided using -k." | tee -a "$err_log"
    exit 1
fi
validate_input "$keyword" "$file" "$directory"
if [[ -n "$file" ]]; then
    if grep -q "$keyword" <<< "$(cat "$file")" 2>> "$err_log"; then
        echo "Found '$keyword' in: $file"
    else
        echo "Keyword '$keyword' not found in $file."
    fi
fi

if [[ -n "$directory" ]]; then
    search_directory "$directory" "$keyword"
fi
echo "Execution completed with status: $?"
